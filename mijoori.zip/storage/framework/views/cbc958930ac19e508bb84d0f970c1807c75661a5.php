   <?php $__env->startSection('content'); ?>
   <div id="make-offer-top" class="rows">
    <div class="fullcontainer">
        <h3>با
            
            <?php echo e($travel->user->name); ?>

            <?php echo e($travel->user->family); ?>

            رزرو کنید
        
        </h3>

        <?php echo $__env->make('main.error', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <form action="<?php echo e(route('send.chat')); ?>" method="post">
            <?php echo csrf_field(); ?>
            <?php echo method_field('post'); ?>
            <textarea  id="" cols="30" rows="10" name="chat" placeholder="پیام شخصی"></textarea>
            <input type="text" name="to" value="<?php echo e($travel->user->id); ?>" hidden>
            <input type="text" name="travel" value="<?php echo e($travel->id); ?>" hidden>
            <button class="btn">ارسال پیام</button>
        </form>
    </div>
</div>
<div id="make-offer" class="rows">
    <div class="fullcontainer">
        <div class="make-offer-side">
            <div class="top">
                <div class="img">
                    <img src="images/mijoorban1.png" alt="">
                </div>
                <div class="name">
                    <h4>
                        <?php echo e($travel->user->name); ?>

                        <?php echo e($travel->user->family); ?>

                    </h4>
                </div>
                <div class="price">
                    <span>200/000</span>
                    <span>تومان</span>
                </div>
                <div class="city">
                    <span>
                        <?php echo e($travel->user->city->name); ?>

                    </span>
                </div>
                <div class="view">
                    <a href="#">مشاهده پروفایل</a>
                </div>
                <div class="stat">
                    <div class="views">
                        <span class="title">بازدید</span>
                        <span>22 نفر</span>
                    </div>
                    <div class="rate">
                        <span class="title">
                            امتیاز
                        </span>
                        <span class="stars">
                            <svg xmlns="http://www.w3.org/2000/svg" width="17.2" height="16.339" viewBox="0 0 17.2 16.339">
                              <g id="Group_209" data-name="Group 209" transform="translate(0 0)">
                                <path id="Path_46" data-name="Path 46" d="M1459.668,226.78a.053.053,0,0,1,0-.032l.327-1.4q.173-.745.346-1.49.18-.77.359-1.539t.359-1.544a.047.047,0,0,0-.019-.054l-1.824-1.58-1.417-1.229-1.359-1.177-.069-.061.125-.01c.126-.012.253-.021.379-.031l.484-.043.379-.031.373-.034.374-.031.378-.033.258-.022.387-.033.258-.022.392-.034.364-.031.392-.034.365-.031.391-.034.36-.031.4-.034c.032,0,.064-.006.1-.007a.054.054,0,0,0,.053-.04c.094-.226.19-.451.286-.677l2.094-4.942.02-.043c.007.014.012.024.016.034l1.619,3.819q.383.9.763,1.8a.065.065,0,0,0,.064.046c.086.006.172.014.258.021l.392.034.359.031.4.034.374.031.378.033.263.022.387.034.263.022.383.033.263.022.387.034.369.031.388.034.258.022.387.033.254.022.365.03s0,0,.008.005-.015.021-.025.029l-1.9,1.647-1.841,1.6q-.434.376-.869.751a.086.086,0,0,0-.034.1c.117.5.232.993.348,1.49s.233,1,.349,1.5q.191.824.383,1.647l.309,1.323a.036.036,0,0,1,0,.023.106.106,0,0,1-.04-.021l-4.561-2.75c-.225-.136-.451-.272-.676-.409a.058.058,0,0,0-.07,0l-2.747,1.657-2.5,1.506C1459.69,226.771,1459.681,226.78,1459.668,226.78Z" transform="translate(-1456.373 -210.442)" fill="currentColor"></path>
                              </g>
                            </svg>
                            <svg xmlns="http://www.w3.org/2000/svg" width="17.2" height="16.339" viewBox="0 0 17.2 16.339">
                              <g id="Group_209" data-name="Group 209" transform="translate(0 0)">
                                <path id="Path_46" data-name="Path 46" d="M1459.668,226.78a.053.053,0,0,1,0-.032l.327-1.4q.173-.745.346-1.49.18-.77.359-1.539t.359-1.544a.047.047,0,0,0-.019-.054l-1.824-1.58-1.417-1.229-1.359-1.177-.069-.061.125-.01c.126-.012.253-.021.379-.031l.484-.043.379-.031.373-.034.374-.031.378-.033.258-.022.387-.033.258-.022.392-.034.364-.031.392-.034.365-.031.391-.034.36-.031.4-.034c.032,0,.064-.006.1-.007a.054.054,0,0,0,.053-.04c.094-.226.19-.451.286-.677l2.094-4.942.02-.043c.007.014.012.024.016.034l1.619,3.819q.383.9.763,1.8a.065.065,0,0,0,.064.046c.086.006.172.014.258.021l.392.034.359.031.4.034.374.031.378.033.263.022.387.034.263.022.383.033.263.022.387.034.369.031.388.034.258.022.387.033.254.022.365.03s0,0,.008.005-.015.021-.025.029l-1.9,1.647-1.841,1.6q-.434.376-.869.751a.086.086,0,0,0-.034.1c.117.5.232.993.348,1.49s.233,1,.349,1.5q.191.824.383,1.647l.309,1.323a.036.036,0,0,1,0,.023.106.106,0,0,1-.04-.021l-4.561-2.75c-.225-.136-.451-.272-.676-.409a.058.058,0,0,0-.07,0l-2.747,1.657-2.5,1.506C1459.69,226.771,1459.681,226.78,1459.668,226.78Z" transform="translate(-1456.373 -210.442)" fill="currentColor"></path>
                              </g>
                            </svg>
                            <svg xmlns="http://www.w3.org/2000/svg" width="17.2" height="16.339" viewBox="0 0 17.2 16.339">
                              <g id="Group_209" data-name="Group 209" transform="translate(0 0)">
                                <path id="Path_46" data-name="Path 46" d="M1459.668,226.78a.053.053,0,0,1,0-.032l.327-1.4q.173-.745.346-1.49.18-.77.359-1.539t.359-1.544a.047.047,0,0,0-.019-.054l-1.824-1.58-1.417-1.229-1.359-1.177-.069-.061.125-.01c.126-.012.253-.021.379-.031l.484-.043.379-.031.373-.034.374-.031.378-.033.258-.022.387-.033.258-.022.392-.034.364-.031.392-.034.365-.031.391-.034.36-.031.4-.034c.032,0,.064-.006.1-.007a.054.054,0,0,0,.053-.04c.094-.226.19-.451.286-.677l2.094-4.942.02-.043c.007.014.012.024.016.034l1.619,3.819q.383.9.763,1.8a.065.065,0,0,0,.064.046c.086.006.172.014.258.021l.392.034.359.031.4.034.374.031.378.033.263.022.387.034.263.022.383.033.263.022.387.034.369.031.388.034.258.022.387.033.254.022.365.03s0,0,.008.005-.015.021-.025.029l-1.9,1.647-1.841,1.6q-.434.376-.869.751a.086.086,0,0,0-.034.1c.117.5.232.993.348,1.49s.233,1,.349,1.5q.191.824.383,1.647l.309,1.323a.036.036,0,0,1,0,.023.106.106,0,0,1-.04-.021l-4.561-2.75c-.225-.136-.451-.272-.676-.409a.058.058,0,0,0-.07,0l-2.747,1.657-2.5,1.506C1459.69,226.771,1459.681,226.78,1459.668,226.78Z" transform="translate(-1456.373 -210.442)" fill="currentColor"></path>
                              </g>
                            </svg>
                            <svg xmlns="http://www.w3.org/2000/svg" width="17.2" height="16.339" viewBox="0 0 17.2 16.339">
                              <g id="Group_209" data-name="Group 209" transform="translate(0 0)">
                                <path id="Path_46" data-name="Path 46" d="M1459.668,226.78a.053.053,0,0,1,0-.032l.327-1.4q.173-.745.346-1.49.18-.77.359-1.539t.359-1.544a.047.047,0,0,0-.019-.054l-1.824-1.58-1.417-1.229-1.359-1.177-.069-.061.125-.01c.126-.012.253-.021.379-.031l.484-.043.379-.031.373-.034.374-.031.378-.033.258-.022.387-.033.258-.022.392-.034.364-.031.392-.034.365-.031.391-.034.36-.031.4-.034c.032,0,.064-.006.1-.007a.054.054,0,0,0,.053-.04c.094-.226.19-.451.286-.677l2.094-4.942.02-.043c.007.014.012.024.016.034l1.619,3.819q.383.9.763,1.8a.065.065,0,0,0,.064.046c.086.006.172.014.258.021l.392.034.359.031.4.034.374.031.378.033.263.022.387.034.263.022.383.033.263.022.387.034.369.031.388.034.258.022.387.033.254.022.365.03s0,0,.008.005-.015.021-.025.029l-1.9,1.647-1.841,1.6q-.434.376-.869.751a.086.086,0,0,0-.034.1c.117.5.232.993.348,1.49s.233,1,.349,1.5q.191.824.383,1.647l.309,1.323a.036.036,0,0,1,0,.023.106.106,0,0,1-.04-.021l-4.561-2.75c-.225-.136-.451-.272-.676-.409a.058.058,0,0,0-.07,0l-2.747,1.657-2.5,1.506C1459.69,226.771,1459.681,226.78,1459.668,226.78Z" transform="translate(-1456.373 -210.442)" fill="currentColor"></path>
                              </g>
                            </svg>
                            <svg xmlns="http://www.w3.org/2000/svg" width="17.2" height="16.339" viewBox="0 0 17.2 16.339">
                              <g id="Group_209" data-name="Group 209" transform="translate(0 0)">
                                <path id="Path_46" data-name="Path 46" d="M1459.668,226.78a.053.053,0,0,1,0-.032l.327-1.4q.173-.745.346-1.49.18-.77.359-1.539t.359-1.544a.047.047,0,0,0-.019-.054l-1.824-1.58-1.417-1.229-1.359-1.177-.069-.061.125-.01c.126-.012.253-.021.379-.031l.484-.043.379-.031.373-.034.374-.031.378-.033.258-.022.387-.033.258-.022.392-.034.364-.031.392-.034.365-.031.391-.034.36-.031.4-.034c.032,0,.064-.006.1-.007a.054.054,0,0,0,.053-.04c.094-.226.19-.451.286-.677l2.094-4.942.02-.043c.007.014.012.024.016.034l1.619,3.819q.383.9.763,1.8a.065.065,0,0,0,.064.046c.086.006.172.014.258.021l.392.034.359.031.4.034.374.031.378.033.263.022.387.034.263.022.383.033.263.022.387.034.369.031.388.034.258.022.387.033.254.022.365.03s0,0,.008.005-.015.021-.025.029l-1.9,1.647-1.841,1.6q-.434.376-.869.751a.086.086,0,0,0-.034.1c.117.5.232.993.348,1.49s.233,1,.349,1.5q.191.824.383,1.647l.309,1.323a.036.036,0,0,1,0,.023.106.106,0,0,1-.04-.021l-4.561-2.75c-.225-.136-.451-.272-.676-.409a.058.058,0,0,0-.07,0l-2.747,1.657-2.5,1.506C1459.69,226.771,1459.681,226.78,1459.668,226.78Z" transform="translate(-1456.373 -210.442)" fill="currentColor"></path>
                              </g>
                            </svg>

                        </span>
                    </div>
                </div>
            </div>
            <div class="bot">
                <ul>
                    <li><a href="#">درباره میجوری</a></li>
                    <li><a href="#">اطلاعات </a></li>
                    <li><a href="#">امنیت حساب</a></li>
                </ul>
            </div>
        </div>
        <div class="make-offer-content-msg">
            <div class="title">
                <h3>پیام های دریافتی</h3>
            </div>
           <?php $__currentLoopData = $travel->chats()->latest()->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
           <div class="offer-content-msg">
            <div class="img">
                <img src="<?php echo e($chat->from->avatar()); ?>" alt="">
            </div>
            <div class="left">
                <div class="msg">
                    <?php echo $chat->chat; ?>

                </div>
                <div class="msg-time">
                    <span>
                        <?php echo e($chat->created_at->diffForHumans()); ?>

                    </span>
                </div>
            </div>
        </div>
           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>
        <div class="guide-notifs">
            <ul>
                <li>
                    <div class="guide-notif">
                        <p>راهنما پیشنهاد مسافر را پذیرفت</p>
                        <span class="date">
                            11:30
                              -  ق. ظ
                              6 اردیبهشت
                              1401
                        </span>
                    </div>
                </li>
                <li>
                    <div class="guide-notif">
                        <p>پرداخت امن به مبلغ   20000        ریال توسط  مسافرپرداخت شد</p>
                        <span class="date">
                            11:30
                              -  ق. ظ
                              6 اردیبهشت
                              1401
                        </span>
                    </div>
                </li>
            </ul>
        </div>
        <div class="make-offer-content exp">
            <div class="mtitle">
                <h3>حسین، مشهد را به شما نشان می دهد</h3>
            </div>
            <div class="timing">
                <div class="top">
                    <div class="time">
                        <svg xmlns="http://www.w3.org/2000/svg" width="40.231" height="40.647" viewBox="0 0 40.231 40.647">
                          <g id="Group_969" data-name="Group 969" transform="translate(0 0)">
                            <path id="Path_214" data-name="Path 214" d="M215.907,288.26H211.63v2.245a3.007,3.007,0,1,1-6.012,0V288.26H193.711v2.245a3.007,3.007,0,1,1-6.012,0V288.26h-4.393a3.869,3.869,0,0,0-3.815,3.9v26.7a3.869,3.869,0,0,0,3.815,3.9h32.6a3.869,3.869,0,0,0,3.815-3.9v-26.7A3.869,3.869,0,0,0,215.907,288.26Zm.694,30.958H182.728V295.94H216.6Z" transform="translate(-179.491 -282.115)" fill="currentColor"></path>
                            <path id="Path_215" data-name="Path 215" d="M371.663,170.071h1.272a1.407,1.407,0,0,0,1.387-1.418v-7.326a1.407,1.407,0,0,0-1.387-1.418h-1.272a1.407,1.407,0,0,0-1.387,1.418v7.326A1.407,1.407,0,0,0,371.663,170.071Z" transform="translate(-361.143 -159.909)" fill="currentColor"></path>
                            <path id="Path_216" data-name="Path 216" d="M745.987,170.071h1.272a1.407,1.407,0,0,0,1.387-1.418v-7.326a1.407,1.407,0,0,0-1.387-1.418h-1.272a1.407,1.407,0,0,0-1.387,1.418v7.326A1.407,1.407,0,0,0,745.987,170.071Z" transform="translate(-717.548 -159.909)" fill="currentColor"></path>
                            <rect id="Rectangle_684" data-name="Rectangle 684" width="7.628" height="7.208" transform="translate(5.491 16.188)" fill="currentColor"></rect>
                            <rect id="Rectangle_685" data-name="Rectangle 685" width="7.628" height="7.208" transform="translate(16.547 16.188)" fill="currentColor"></rect>
                            <rect id="Rectangle_686" data-name="Rectangle 686" width="7.628" height="7.208" transform="translate(26.938 16.188)" fill="currentColor"></rect>
                            <rect id="Rectangle_687" data-name="Rectangle 687" width="7.628" height="7.208" transform="translate(5.491 26.822)" fill="currentColor"></rect>
                            <rect id="Rectangle_688" data-name="Rectangle 688" width="7.628" height="7.208" transform="translate(16.547 26.822)" fill="currentColor"></rect>
                            <rect id="Rectangle_689" data-name="Rectangle 689" width="7.628" height="7.208" transform="translate(26.938 26.822)" fill="currentColor"></rect>
                          </g>
                        </svg>

                        <span>
                            20 خرداد 1401
                        </span>
                        <span>-</span>
                        <span>25 خرداد 1401</span>

                    </div>
                    <div class="price">
                        <div class="number">
                            <span>200/000</span>
                            <span>تومان</span>
                        </div>
                        <div class="hour">
                            <span>برای 2 ساعت</span>
                        </div>
                    </div>
                </div>
                <div class="bot">
                    <ul>
                        <li>
                            <span class="title">تعداد افراد :</span>
                            <span>خودم</span>
                        </li>
                        <li>
                            <span class="title">زمان ملاقات :</span>
                            <span>عصر</span>
                        </li>
                    </ul>
                </div>
            </div>
            <div class="texte">
                <div class="img">
                    <img src="images/mijoorban1.png" alt="">
                </div>
                <div class="text">
                    <p>
                        حسین، مشهد را به شما نشان می دهد  حسین، مشهد را به شما نشان می دهدحسین، مشهد را به شما نشان می دهدحسین، مشهد را به شما نشان می دهدحسین، مشهد را به شما نشان می دهدحسین، مشهد را به شما نشان می دهدحسین، مشهد را به شما نشان می دهدحسین، مشهد را به شما نشان می دهد
                    </p>
                </div>
            </div>

            <div class="buttons">
                <button class="violet">متن</button>
                <button class="gray">متن</button>
            </div>

        </div>
    </div>
</div>
   <?php $__env->stopSection(); ?>

<?php echo $__env->make('main.site', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\laravelProject\mijoori\resources\views/home/travel_chat.blade.php ENDPATH**/ ?>