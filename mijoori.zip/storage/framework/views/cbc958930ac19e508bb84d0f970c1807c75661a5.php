   <?php $__env->startSection('content'); ?>
   <div id="make-offer-top" class="rows">
    <div class="fullcontainer">
        <h3>با
            
            <?php echo e($travel->user->name); ?>

            <?php echo e($travel->user->family); ?>

            رزرو کنید
        
        </h3>
        <?php if($travel->host_accept): ?>
        <?php
        $to=$travel->host->id;
               if ($travel->host->id==auth()->user()->id){
                $to=$travel->user->id;
               }


        ?>
        <?php echo $__env->make('main.error', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <form action="<?php echo e(route('send.chat')); ?>" method="post">
            <?php echo csrf_field(); ?>
            <?php echo method_field('post'); ?>
            <textarea  id="" cols="30" rows="10" name="chat" placeholder="پیام شخصی"></textarea>
            <input type="text" name="to" value="<?php echo e($to); ?>" hidden>
            <input type="text" name="travel" value="<?php echo e($travel->id); ?>" hidden>
            <button class="btn">ارسال پیام</button>
        </form>
        <?php endif; ?>
    </div>
</div>

<div id="make-offer" class="rows">
    <div class="fullcontainer">
        <?php if($travel->host): ?>
        <?php if($travel->host->id != auth()->user()->id ): ?>

        <div class="make-offer-side">
            <div class="top">
                <div class="img">
                    <img src="<?php echo e($travel->host->avatar()); ?>" alt="">
                </div>
                <div class="name">
                    <h4>
                          <?php echo e($travel->host->name); ?>

                          <?php echo e($travel->host->family); ?>

                    </h4>
                </div>
                <div class="price">
                    <span>200/000</span>
                    <span>تومان</span>
                </div>
                <div class="city">
                    <span><?php echo e($travel->city->name); ?></span>
                </div>
                <div class="view">
                    <a href="<?php echo e(route('profile',$travel->host->id)); ?>">مشاهده پروفایل</a>
                </div>
                <div class="stat">
                    <div class="views">
                        <span class="title">بازدید</span>
                        <span>22 نفر</span>
                    </div>
                    <div class="rate">
                        <span class="title">
                            امتیاز
                        </span>
                        <span class="stars">
                            <?php echo $__env->make('home.parts.rate',['rate'=>$travel->host->rates()], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                        </span>
                    </div>
                </div>
            </div>
            <div class="bot">
                <ul>
                    <li><a href="#">درباره میجوری</a></li>
                    <li><a href="#">اطلاعات </a></li>
                    <li><a href="#">امنیت حساب</a></li>
                </ul>
            </div>
        </div>
        <?php endif; ?>

        <?php endif; ?>

    <?php if($travel->host_accept): ?>

    <div class="make-offer-content-msg">
        <div class="title">
            <h3>پیام های دریافتی</h3>
        </div>



        <?php $__currentLoopData = $travel->chats()->latest()->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chatys): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="offer-content-msg <?php echo e($chatys->to->id==$user->id ? '':'rev'); ?>">


            <div class="img">
                <img src="<?php echo e($chatys->to->id==$user->id ? $chatys->from->avatar():$user->avatar()); ?>" alt="">
               
            </div>
            <div class="left">
                <div class="msg">
                  <?php echo e($chatys->chat); ?>


                </div>
                <div class="msg-time">
                    <span>             <?php echo e($chatys->created_at->diffForHumans()); ?></span>
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>





    </div>
        <?php else: ?>
        <div class="make-offer-content">
            <div class="mtitle">
                <h3>


                    <?php if($travel->host): ?>


                     <?php if($travel->host->id==auth()->user()->id): ?>

                     <a href="<?php echo e(route('profile',$travel->user->id)); ?>">
                        <?php echo e($travel->user->name); ?>

                        <?php echo e($travel->user->family); ?>

                    </a>
                    درخواست سفر در
                    <?php echo e($travel->city?$travel->city->name:''); ?>


                    را دارد
                    <?php else: ?>

                    <a href="<?php echo e(route('profile',$travel->host->id)); ?>">
                        <?php echo e($travel->host->name); ?>

                        <?php echo e($travel->city?$travel->city->name:''); ?>

                    </a>


                    <?php endif; ?>
                    <?php endif; ?>

                    </h3>
            </div>
            <div class="timing">
                <div class="top">
                    <div class="time">
                        <svg xmlns="http://www.w3.org/2000/svg" width="40.231" height="40.647" viewBox="0 0 40.231 40.647">
                          <g id="Group_969" data-name="Group 969" transform="translate(0 0)">
                            <path id="Path_214" data-name="Path 214" d="M215.907,288.26H211.63v2.245a3.007,3.007,0,1,1-6.012,0V288.26H193.711v2.245a3.007,3.007,0,1,1-6.012,0V288.26h-4.393a3.869,3.869,0,0,0-3.815,3.9v26.7a3.869,3.869,0,0,0,3.815,3.9h32.6a3.869,3.869,0,0,0,3.815-3.9v-26.7A3.869,3.869,0,0,0,215.907,288.26Zm.694,30.958H182.728V295.94H216.6Z" transform="translate(-179.491 -282.115)" fill="currentColor"></path>
                            <path id="Path_215" data-name="Path 215" d="M371.663,170.071h1.272a1.407,1.407,0,0,0,1.387-1.418v-7.326a1.407,1.407,0,0,0-1.387-1.418h-1.272a1.407,1.407,0,0,0-1.387,1.418v7.326A1.407,1.407,0,0,0,371.663,170.071Z" transform="translate(-361.143 -159.909)" fill="currentColor"></path>
                            <path id="Path_216" data-name="Path 216" d="M745.987,170.071h1.272a1.407,1.407,0,0,0,1.387-1.418v-7.326a1.407,1.407,0,0,0-1.387-1.418h-1.272a1.407,1.407,0,0,0-1.387,1.418v7.326A1.407,1.407,0,0,0,745.987,170.071Z" transform="translate(-717.548 -159.909)" fill="currentColor"></path>
                            <rect id="Rectangle_684" data-name="Rectangle 684" width="7.628" height="7.208" transform="translate(5.491 16.188)" fill="currentColor"></rect>
                            <rect id="Rectangle_685" data-name="Rectangle 685" width="7.628" height="7.208" transform="translate(16.547 16.188)" fill="currentColor"></rect>
                            <rect id="Rectangle_686" data-name="Rectangle 686" width="7.628" height="7.208" transform="translate(26.938 16.188)" fill="currentColor"></rect>
                            <rect id="Rectangle_687" data-name="Rectangle 687" width="7.628" height="7.208" transform="translate(5.491 26.822)" fill="currentColor"></rect>
                            <rect id="Rectangle_688" data-name="Rectangle 688" width="7.628" height="7.208" transform="translate(16.547 26.822)" fill="currentColor"></rect>
                            <rect id="Rectangle_689" data-name="Rectangle 689" width="7.628" height="7.208" transform="translate(26.938 26.822)" fill="currentColor"></rect>
                          </g>
                        </svg>

                        <span>
                          <?php echo e(Morilog\Jalali\Jalalian::forge($travel->start)->format('%B %d، %Y')); ?>

                        </span>
                        <span>-</span>
                        <span>      <?php echo e(Morilog\Jalali\Jalalian::forge($travel->start)->format('%B %d، %Y')); ?>    </span>

                    </div>
                    <div class="price">
                        <div class="number">
                            <span>200/000</span>
                            <span>تومان</span>
                        </div>
                        <div class="hour">
                            <span>برای 2 ساعت</span>
                        </div>
                    </div>
                </div>
                <div class="bot">
                    <ul>
                        <li>
                            <span class="title">تعداد افراد :</span>
                            <span>
                                <?php echo e($travel->count==1 ? 'خودم':$travel->count); ?>

                            </span>
                        </li>
                        <li>
                            <span class="title">زمان ملاقات :</span>
                            <span>

                            <?php echo e(__('arr.'.$travel->visit)); ?>

                            </span>
                        </li>
                    </ul>
                </div>
            </div>
            <div class="texte">
                <div class="img">
                    <?php if($travel->host): ?>

                    <?php if($travel->host->id==auth()->user()->id): ?>
                    <?php else: ?>
                    <?php endif; ?>
                    <?php if($travel->host->id==auth()->user()->id): ?>
                    <img src="<?php echo e($travel->user->avatar()); ?>" alt="">

                    <?php else: ?>
                    <img src="<?php echo e($travel->host->avatar()); ?>" alt="">
                    <?php endif; ?>
                    <?php endif; ?>

                </div>
                <div class="text">
                    <p>
                        <?php
                            $ch=$travel->chats()->oldest()->first()
                        ?>

                        <?php echo e($ch?$ch->chat:''); ?>

                    </p>
                </div>
            </div>

            <div class="buttons">
               <form action="<?php echo e(route('related.chat',$travel->id)); ?>" method="post">
                <?php echo csrf_field(); ?>
                <?php echo method_field('post'); ?>
                <input name="accept" type="submit" class="violet btt" value="قبول">
                <input name="reject" type="submit" class="gray btt" value="رد">
               </form>
            </div>

        </div>

        <?php endif; ?>


    </div>
</div>

   <?php $__env->stopSection(); ?>

<?php echo $__env->make('main.site', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\laravelProject\mijoori\resources\views/home/travel_chat.blade.php ENDPATH**/ ?>