<?php if($errors->any()): ?>
    <div class="er">
        <?php echo implode('', $errors->all('<span class="text text-danger">:message</span>')); ?>

    </div>
<?php endif; ?>
<?php /**PATH G:\laravelProject\mijoori\resources\views/main/error.blade.php ENDPATH**/ ?>