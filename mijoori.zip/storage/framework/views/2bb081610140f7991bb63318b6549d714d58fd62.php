   <?php $__env->startSection('content'); ?>
   <?php echo e(Breadcrumbs::render('travel.index')); ?>


   <div class="col-lg-12">
    <div class="portlet box border shadow">
        <div class="portlet-heading">
            <div class="portlet-title">
                <h3 class="title">
                    <i class="icon-frane"></i>
                    جدول سفرها
                </h3>
            </div><!-- /.portlet-title -->
            <div class="buttons-box">
            </div><!-- /.buttons-box -->
        </div><!-- /.portlet-heading -->
        <div class="portlet-body">
                <div class="row">
                    <form action="<?php echo e(route('travel.index')); ?>" method="get">

                    <div class="col-lg-3">
                        <div class="form-group row">
                            <label class="col-sm-3">جست و جو</label>
                            <div class="col-sm-9">
                                <input type="text" class="form-control" name="search" value="<?php echo e(request('search')); ?>" placeholder="  نام و موبایل و ....  ">
                            </div>
                        </div>
                    </div>
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('get'); ?>
                    <div class="col-lg-3">
                        <div class="form-group row">
                            <button class="btn btn-danger curve" ">ثبت</button>
                        </div>
                    </div>
                </form>
                </div>

            <div class="table-responsive">
                <table class="table">
                    <thead>
                        <tr>


                            <th><i class="icon-energy"></i></th>
                            <th>نام</th>
                            <th>شهر </th>
                            <th>میزبان </th>
                            <th>شروع </th>
                            <th>پایان </th>
                            <th>تعداد </th>
                            <th>جنسیت </th>
                            <th>وضعیت </th>
                            <th>تایید</th>
                            <th>اقداام</th>

                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $travels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $travel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($loop->iteration + (($travels->currentPage()-1) *($travels->perPage()))); ?></td>
                            <td>
                               <a target="_blank" href="<?php echo e(route('user.show',$travel->user->id)); ?>">
                                <?php echo e($travel->user->name); ?>

                                <?php echo e($travel->user->family); ?>

                               </a>
                            </td>
                            <td>
                                <?php echo e($travel->city->name); ?>

                                <?php echo e($travel->province->name); ?>

                            </td>
                            <td>
                                <?php if($travel->host): ?>
                                <?php echo e($travel->host->name); ?>

                                <?php echo e($travel->host->family); ?>

                                <?php endif; ?>
                            </td>
                            <td><?php echo e($user->fdate($travel->start,'Y-m-d')); ?></td>
                            <td><?php echo e($user->fdate($travel->end,'Y-m-d')); ?></td>
                            <td>
                                <?php echo e($travel->count); ?>

                            </td>
                            <td><?php echo e(__('arr.'.$travel->gender)); ?></td>
                            <td>
                               <span class="text text-<?php echo e($travel->active?"success":'danger'); ?>">
                                (<?php echo e($travel->active?"فعال":'غیرفعال'); ?>)
                               </span>
                            </td>
                            <td>
                                <span class="text text-<?php echo e($travel->confirm?"success":'danger'); ?>">
                                 (<?php echo e($travel->confirm?"تایید شده":'تایید نشده'); ?>)
                                </span>
                             </td>
                            <td><?php echo e($travel->email); ?></td>

                            <td>
                                (<?php echo e($travel->confirm?"تایید شده":'تایید نشده'); ?>)
                            <?php if(auth()->check() && auth()->user()->hasRole('admin')): ?>
                            <?php if(!$travel->confirm): ?>
                            <a class="btn btn-<?php echo e($travel->confirm?"danger":'primary'); ?> curve" href="<?php echo e(route('travel.confirm',$travel->id)); ?>"><?php echo e($travel->confirm?"  رد":'  تایید'); ?></a>

                            <?php endif; ?>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                    </tbody>
                </table>
            </div><!-- /.table-responsive -->
        </div><!-- /.portlet-body -->
    </div><!-- /.portlet -->
</div>
   <?php $__env->stopSection(); ?>

<?php echo $__env->make('main.manager', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\laravelProject\mijoori\resources\views/admin/travels/all.blade.php ENDPATH**/ ?>