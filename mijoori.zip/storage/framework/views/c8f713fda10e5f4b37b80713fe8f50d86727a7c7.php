   <?php $__env->startSection('content'); ?>
   <?php echo e(Breadcrumbs::render('user.index')); ?>


   <div class="col-lg-12">
    <div class="portlet box border shadow">
        <div class="portlet-heading">
            <div class="portlet-title">
                <h3 class="title">
                    <i class="icon-frane"></i>
                    جدول کاربران
                </h3>
            </div><!-- /.portlet-title -->
            <div class="buttons-box">

            </div><!-- /.buttons-box -->
        </div><!-- /.portlet-heading -->
        <div class="portlet-body">
            <form action="">
                <div class="row">
                    <div class="col-lg-3">
                        <div class="form-group row">
                            <label class="col-sm-3">جست و جو</label>
                            <div class="col-sm-9">
                                <input type="text" class="form-control" name="search" value="<?php echo e(request('search')); ?>" placeholder="  نام و موبایل و ....  ">
                            </div>
                        </div>
                    </div>
                    <form action="<?php echo e(route('user.index')); ?>" method="get">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('get'); ?>
                    <div class="col-lg-3">
                        <div class="form-group row">
                            <button class="btn btn-danger curve" ">ثبت</button>
                        </div>
                    </div>
                </form>
                </div>

            </form>
            <div class="table-responsive">
                <table class="table">
                    <thead>
                        <tr>


                            <th><i class="icon-energy"></i></th>
                            <th>نام</th>
                            <th>همراه </th>
                            <th>ایمیل</th>
                            <th>مکان </th>
                            <th>بیشتر</th>

                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <tr>
                            <td><?php echo e($loop->iteration + (($users->currentPage()-1) *($users->perPage()))); ?></td>
                            <td>
                                <?php echo e($user->name); ?>

                                <?php echo e($user->family); ?>

                            </td>
                            <td><?php echo e($user->mobile); ?></td>
                            <td><?php echo e($user->email); ?></td>
                            <td>
                                <?php echo e($user->province?$user->province->name:''); ?>

                                <?php echo e($user->city?$user->city->name:''); ?>

                            </td>
                            <td>
                            <a class="btn btn-primary curve" href="<?php echo e(route('user.show',$user->id)); ?>">پروفایل</button>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                    </tbody>
                </table>
            </div><!-- /.table-responsive -->
        </div><!-- /.portlet-body -->
    </div><!-- /.portlet -->
</div>
   <?php $__env->stopSection(); ?>

<?php echo $__env->make('main.manager', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\laravelProject\mijoori\resources\views/admin/users/all.blade.php ENDPATH**/ ?>