<!DOCTYPE html>
<html lang="fa">
<head>
    <meta charset="UTF-8">

    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
    <title><?php echo $__env->yieldContent('title'); ?></title>
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="/home/css/style.css">
    <link rel="stylesheet" href="/css/iziToast.css">
    <link rel="stylesheet" href="/css/persian-datepicker.min.css">
    <link rel="stylesheet" href="/css/jquery.loadingModal.css">
    
    <link rel="stylesheet" href="/css/select2.min.css">
    <link rel="stylesheet" href="/css/css.css">
    <link rel="shortcut icon" href="/home/images/logo.png">
    <link rel="apple-touch-icon" href="/home/images/logo.png">

</head>

<body>
<?php echo $__env->make('home.parts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->yieldContent('content'); ?>

<?php echo $__env->make('home.parts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>




<script src="/home/js/jquery-2.2.0.min.js"></script>
<script src="/home/js/owl.carousel.min.js"></script>
<script src="/home/js/aos.js"></script>

<script src="/home/js/glightbox.min.js"></script>
<script src="/home/js/nouislider.min.js"></script>
<script src="/home/js/wNumb.min.js"></script>
<script src="/home/js/jquery.mmenu.min.all.js"></script>
<script src="/home/js/template.js"></script>
<script type="text/javascript" src="/js/iziToast.js"></script>
<script src="/js/persian-date.min.js"></script>
<script src="/js/persian-datepicker.min.js"></script>
<script src="/js/jquery.loadingModal.min.js"></script>
<script src="/admin/assets/js/lightbox.min.js"></script>
<script src="/js/fun.js"></script>
<script src="/js/simpleupload.js"></script>
<script src="/js/jquery.validate.min.js"></script>
<script src="/js/select2.full.min.js"></script>
<script src="/js/js1.js"></script>



</body>
<?php echo $__env->make('sweetalert::alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</html>
<?php /**PATH G:\laravelProject\mijoori\resources\views/main/site.blade.php ENDPATH**/ ?>