   <?php $__env->startSection('content'); ?>
    <?php echo $__env->make('breadcrumb', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <!-- BEGIN WRAPPER -->
        <div class="fixed-modal-bg"></div>
        <a href="#" class="btn btn-info btn-icon btn-round btn-lg" id="toggle-dark-mode">
            <i class="icon-bulb"></i>
        </a>
        <div class="modal-page shadow">
            <div class="container-fluid">
                <div class="row">

                    <div class="col-md-12">
                        <div class="logo-con m-t-10 m-b-10">
                            
                        </div><!-- /.logo-con -->

                        <h1 class="text-center m-b-20">  میجوری</h1>
                        <hr>
                        <?php echo $__env->make('main.error', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <form id="form" class="m-t-30 m-b-30" action="<?php echo e(route('admin.check.login')); ?>" autocomplete="off" method="POST" role="form">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('post'); ?>
                            <div class="form-group">
                                <label for="email" class="sr-only">رایانامه</label>
                                <div class="input-group round">
                                    <span class="input-group-addon">
                                        <i class="icon-envelope"></i>
                                    </span>
                                    <input id="email" class="form-control ltr text-left" type="email" name="email" required>
                                </div><!-- /.input-group -->
                            </div><!-- /.form-group -->
                            <div class="form-group">
                                <label for="password" class="sr-only">رمز عبور</label>
                                <div class="input-group round">
                                    <span class="input-group-addon">
                                        <i class="icon-key"></i>
                                    </span>
                                    <input id="password" class="form-control ltr text-left" type="password" name="password"  required>
                                </div><!-- /.input-group -->
                            </div><!-- /.form-group -->
                            <div class="form-group">
                            <div id="form_id_1">

                            </div>
                            </div>
                            <p>
                                <button class="btn btn-info btn-round btn-block" type="submit">
                                    <i class="icon-paper-plane font-lg"></i>
                                    ورود
                                </button>
                            </p>
                        </form>

                    </div><!-- /.col-md-12 -->
                </div><!-- /.row -->
            </div><!-- /.container-fluid -->
        </div><!-- /.modal-page -->
        <!-- END WRAPPER -->

        <?php echo GoogleReCaptchaV2::render('form_id_1'); ?>

   <?php $__env->stopSection(); ?>

<?php echo $__env->make('main.manager', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\laravelProject\mijoori\resources\views/admin/users/index.blade.php ENDPATH**/ ?>