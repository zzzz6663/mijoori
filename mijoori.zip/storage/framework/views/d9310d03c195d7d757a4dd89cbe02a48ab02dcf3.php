   <?php $__env->startSection('content'); ?>
    <?php echo $__env->make('main.breadcrumbs', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="col-lg-12">
        <div class="portlet box border shadow">
            <div class="portlet-heading">
                <div class="portlet-title">
                    <h3 class="title">
                        <i class="icon-frane"></i>
                        جدول کاربران
                    </h3>
                </div><!-- /.portlet-title -->
                <div class="buttons-box">

                </div><!-- /.buttons-box -->
            </div><!-- /.portlet-heading -->
            <div class="portlet-body">
                
                <div class="table-responsive">
                    <table class="table">
                        <thead>
                            <tr>


                                <th><i class="icon-energy"></i></th>
                                <th>نام</th>
                                <th>همراه </th>
                                <th>ایمیل</th>
                                <th>مکان </th>
                                <th>بیشتر</th>

                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <tr>
                                <td><?php echo e($loop->iteration + (($users->currentPage()-1) *($users->perPage()))); ?></td>
                                <td>
                                    <?php echo e($user->name); ?>

                                    <?php echo e($user->family); ?>

                                </td>
                                <td><?php echo e($user->mobile); ?></td>
                                <td><?php echo e($user->email); ?></td>
                                <td>
                                    <?php echo e($user->province?$user->province->name:''); ?>

                                    <?php echo e($user->city?$user->city->name:''); ?>

                                </td>
                                <td>
                                <a class="btn btn-primary curve" href="<?php echo e(route('user.show',$user->id)); ?>">پروفایل</button>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                        </tbody>
                    </table>
                </div><!-- /.table-responsive -->
            </div><!-- /.portlet-body -->
        </div><!-- /.portlet -->
    </div>

    <div class="breadcrumb-box border shadow">
        <ul class="breadcrumb">
            <a href="<?php echo e(route('province.index')); ?>" class="btn btn-danger">برگشت</a>
                </ul>

        </div><!-- /.breadcrumb-left -->
    </div>
   <?php $__env->stopSection(); ?>

<?php echo $__env->make('main.manager', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\laravelProject\mijoori\resources\views/admin/provinces/show.blade.php ENDPATH**/ ?>