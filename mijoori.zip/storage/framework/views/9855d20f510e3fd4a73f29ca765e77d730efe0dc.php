   <?php $__env->startSection('content'); ?>

   <div id="top-banner" class="rows">
    <?php if($travels->count()>0): ?>

    <ul class="my_travel owl-carousel owl-theme side-nav">
        <?php $__currentLoopData = $travels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $travel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
             <li>
                <img src="<?php echo e($travel->city->banner()); ?>" alt="">
             </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </ul>
        <?php else: ?>

    <img src="/home/images/travel.jpg" alt="">

    <?php endif; ?>
</div>


<div id="mytrips" class="rows">
    <div class="fullcontainer">
        <div class="row">
            <div class="col-lg-12">
                <div>
                    <div class="bg-center-title">
                        <h3>
                            <span class="icon">
                                <svg xmlns="http://www.w3.org/2000/svg" width="24.871" height="34.705" viewBox="0 0 24.871 34.705">
                                  <g id="Group_931" data-name="Group 931" transform="translate(-1022.001 -976.999)">
                                    <g id="Group_930" data-name="Group 930" transform="translate(-899.367 224.947)">
                                      <g id="Group_928" data-name="Group 928" transform="translate(1921.368 752.052)">
                                        <path fill="currentColor" id="Path_219" data-name="Path 219" d="M1933.8,786.757a1.648,1.648,0,0,1-1.27-.6c-.456-.551-11.166-13.579-11.166-21.673a12.436,12.436,0,1,1,24.871,0c0,8.094-10.71,21.122-11.166,21.673A1.648,1.648,0,0,1,1933.8,786.757Zm0-31.409a9.15,9.15,0,0,0-9.14,9.139c0,5.028,5.762,13.577,9.139,17.972,3.377-4.4,9.14-12.95,9.14-17.972A9.15,9.15,0,0,0,1933.8,755.348Z" transform="translate(-1921.368 -752.052)"/>
                                      </g>
                                      <g id="Group_929" data-name="Group 929" transform="translate(1928.263 758.999)">
                                        <path fill="currentColor" id="Path_220" data-name="Path 220" d="M2004.841,833.873a2.245,2.245,0,1,1-2.245,2.245,2.247,2.247,0,0,1,2.245-2.245m0-3.3a5.541,5.541,0,1,0,5.541,5.541,5.541,5.541,0,0,0-5.541-5.541Z" transform="translate(-1999.3 -830.577)"/>
                                      </g>
                                    </g>
                                  </g>
                                </svg>

                            </span>
                            سـفرهـای من
                        </h3>
                    </div>
                </div>
            </div>
        </div>

        <div class="row">
            <?php $__currentLoopData = $travels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $travel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-lg-6 col-md-12">
                <div>
                    <div class="single-my-trip">
                        <div class="img">
                            <a href="#">
                                <img src="<?php echo e($travel->city->image()); ?>" alt="">
                            </a>
                            <div class="cap">
                                <h4>سفر به
                                    <?php echo e($travel->city->name); ?>

                                </h4>
                                <span class="icon">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="24.871" height="34.705" viewBox="0 0 24.871 34.705">
                                      <g id="Group_931" data-name="Group 931" transform="translate(-1022.001 -976.999)">
                                        <g id="Group_930" data-name="Group 930" transform="translate(-899.367 224.947)">
                                          <g id="Group_928" data-name="Group 928" transform="translate(1921.368 752.052)">
                                            <path fill="currentColor" id="Path_219" data-name="Path 219" d="M1933.8,786.757a1.648,1.648,0,0,1-1.27-.6c-.456-.551-11.166-13.579-11.166-21.673a12.436,12.436,0,1,1,24.871,0c0,8.094-10.71,21.122-11.166,21.673A1.648,1.648,0,0,1,1933.8,786.757Zm0-31.409a9.15,9.15,0,0,0-9.14,9.139c0,5.028,5.762,13.577,9.139,17.972,3.377-4.4,9.14-12.95,9.14-17.972A9.15,9.15,0,0,0,1933.8,755.348Z" transform="translate(-1921.368 -752.052)"/>
                                          </g>
                                          <g id="Group_929" data-name="Group 929" transform="translate(1928.263 758.999)">
                                            <path fill="currentColor" id="Path_220" data-name="Path 220" d="M2004.841,833.873a2.245,2.245,0,1,1-2.245,2.245,2.247,2.247,0,0,1,2.245-2.245m0-3.3a5.541,5.541,0,1,0,5.541,5.541,5.541,5.541,0,0,0-5.541-5.541Z" transform="translate(-1999.3 -830.577)"/>
                                          </g>
                                        </g>
                                      </g>
                                    </svg>
                                </span>
                            </div>
                        </div>

                        <div class="dets">
                            <div class="date-action">
                                <div class="date">
                                    <span class="icon">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="25.527" height="25.791" viewBox="0 0 25.527 25.791">
                                          <g id="Group_902" data-name="Group 902" transform="translate(-179.491 -159.909)">
                                            <path id="Path_215" data-name="Path 215" d="M202.6,288.26h-2.714v1.425a1.908,1.908,0,1,1-3.814,0V288.26h-7.556v1.425a1.908,1.908,0,1,1-3.814,0V288.26h-2.787a2.455,2.455,0,0,0-2.421,2.474v16.944a2.455,2.455,0,0,0,2.421,2.474H202.6a2.455,2.455,0,0,0,2.421-2.474V290.734A2.455,2.455,0,0,0,202.6,288.26Zm.44,19.643H181.545v-14.77h21.493Z" transform="translate(0 -124.452)" fill="currentColor"/>
                                            <path id="Path_216" data-name="Path 216" d="M371.156,166.357h.807a.893.893,0,0,0,.88-.9v-4.648a.893.893,0,0,0-.88-.9h-.807a.893.893,0,0,0-.88.9v4.648A.893.893,0,0,0,371.156,166.357Z" transform="translate(-184.99)" fill="currentColor"/>
                                            <path id="Path_217" data-name="Path 217" d="M745.48,166.357h.807a.893.893,0,0,0,.88-.9v-4.648a.893.893,0,0,0-.88-.9h-.807a.893.893,0,0,0-.88.9v4.648A.893.893,0,0,0,745.48,166.357Z" transform="translate(-547.944)" fill="currentColor"/>
                                            <rect id="Rectangle_686" data-name="Rectangle 686" width="4.84" height="4.573" transform="translate(182.975 170.18)" fill="currentColor"/>
                                            <rect id="Rectangle_687" data-name="Rectangle 687" width="4.84" height="4.573" transform="translate(189.99 170.18)" fill="currentColor"/>
                                            <rect id="Rectangle_688" data-name="Rectangle 688" width="4.84" height="4.573" transform="translate(196.584 170.18)" fill="currentColor"/>
                                            <rect id="Rectangle_689" data-name="Rectangle 689" width="4.84" height="4.573" transform="translate(182.975 176.928)" fill="currentColor"/>
                                            <rect id="Rectangle_690" data-name="Rectangle 690" width="4.84" height="4.573" transform="translate(189.99 176.928)" fill="currentColor"/>
                                            <rect id="Rectangle_691" data-name="Rectangle 691" width="4.84" height="4.573" transform="translate(196.584 176.928)" fill="currentColor"/>
                                          </g>
                                        </svg>

                                    </span>

                                    <?php echo e($user->fdate($travel->start)->format('%A, %d %B %Y')); ?> -
                                    <?php echo e($user->fdate($travel->end)->format('%A, %d %B %Y')); ?>

                                    <span style="display:inline-block; margin-left:10px; color:<?php echo e($travel->active?"green":'red'); ?>">
                                    (<?php echo e($travel->active?"فعال":'غیرفعال'); ?>)
                                    </span>

                                </div>

                                <div class="actions">

                                    <?php if( !$travel->confirm): ?>

                                    <a href="<?php echo e(route('user.travel.destroy',$travel->id)); ?>">حذف</a>
                                    <span>/</span>

                                    <a href="<?php echo e(route('user.travel.active',$travel->id)); ?>"><?php echo e($travel->active?"غیرفعال":'فعال'); ?></a>
                                    <?php endif; ?>

                                </div>
                            </div>
                            <div class="numbers">
                                <span class="title">تعداد افراد :</span>
                                <span class="value"> <?php echo e($travel->count); ?></span>
                            </div>
                            <div class="offers">
                                <h4>پیشنهادات دریافت شده از :</h4>
                                <ul>
                                    <li>
                                        <a href="#">
                                            <img src="images/mijoorban1.png" alt="">
                                        </a>
                                    </li>

                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>
    </div>
</div>


   <?php $__env->stopSection(); ?>

<?php echo $__env->make('main.site', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\laravelProject\mijoori\resources\views/home/my_travels.blade.php ENDPATH**/ ?>