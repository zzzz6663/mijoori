   <?php $__env->startSection('content'); ?>
   <?php echo e(Breadcrumbs::render('province.edit',$province)); ?>

    <div class="col-lg-6">
        <div class="portlet box border shadow">
            <div class="portlet-heading">
                <div class="portlet-title">
                    <h3 class="title">
                        <i class="icon-frane"></i>
                        به روز رسانی تصویر  استان
                        <?php echo e($province->name); ?>

                    </h3>
                </div><!-- /.portlet-title -->
                <div class="buttons-box">

                </div><!-- /.buttons-box -->
            </div><!-- /.portlet-heading -->
            <div class="portlet-body">
                <?php echo $__env->make('main.error', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <form action="<?php echo e(route('province.update',$province->id)); ?>" method="post"  enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PATCH'); ?>
                    <div class="row">
                        <div class="col-lg-12">

                            <div class="form-group relative">
                                <input type="file"  accept="image/*" name="image" class="form-control">
                                <label>آپلود فایل</label>
                                <div class="input-group round">
                                    <input type="text" class="form-control file-input" placeholder="برای آپلود کلیک کنید">
                                    <span class="input-group-btn">
                                        <button type="button" class="btn btn-info">
                                            <i class="icon-picture"></i>
                                            آپلود عکس
                                        <div class="paper-ripple"><div class="paper-ripple__background"></div><div class="paper-ripple__waves"></div></div></button>
                                    </span>
                                </div><!-- /.input-group -->
                                <div class="help-block"></div>
                            </div>
                            <div class="form-group relative">
                                <button type="submit" class="btn btn-info curve">
                                    ذخیره
                                <div class="paper-ripple"><div class="paper-ripple__background"></div><div class="paper-ripple__waves"></div></div></button>
                            </div>
                        </div>

                    </div>

                </form>

            </div><!-- /.portlet-body -->
        </div><!-- /.portlet -->
    </div>
   <?php $__env->stopSection(); ?>

<?php echo $__env->make('main.manager', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\laravelProject\mijoori\resources\views/admin/provinces/edit.blade.php ENDPATH**/ ?>