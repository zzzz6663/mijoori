   <?php $__env->startSection('content'); ?>
   <div id="my-adventures" class="rows">
    <div class="fullcontainer">
        <div class="row">
            <div class="col-lg-8 col-md-10 col-sm-12 center-block">
                <div>

                    <div class="adv-table">
                        <div class="header">
                            <h3>
                            ماجراجویانه های من

                            </h3>
                        </div>
                        <?php $__currentLoopData = $adventures; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $adventure): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <div class="my-single-adv">
                            <div class="right">
                                <div class="pic">
                                    <img src="<?php echo e($adventure->image()); ?>" alt="">
                                </div>
                                <div class="info">
                                    <h4>  <?php echo e($adventure->name); ?></h4>
                                    <span class="disc">
                                        <?php echo e(__('arr.'.$adventure->cat)); ?>

                                        -
                                        <?php echo e(__('arr.'.$adventure->hardness)); ?>


                                        </span>
                                        <?php if($adventure->stage==5): ?>

                                        <span class="stat        <?php echo e($adventure->confirm==1?'green':'violet'); ?>">
                                            <?php echo e($adventure->confirm==1?'تایید':'در انتظار تایید '); ?>

                                        </span>
                                        <?php else: ?>
                                        <span class="stat        <?php echo e($adventure->stage==5?'green':'violet'); ?>">
                                            <?php echo e($adventure->confirm==5?'تکمیل شده':'نکمیل نشده'); ?>

                                        </span>
                                        <?php endif; ?>


                                </div>
                            </div>
                            <div class="left">
                                <?php if($adventure->stage==5): ?>
                                <a href="<?php echo e(route('new.adventure1',$adventure->id)); ?>" class="edit">ویرایش تور</a>
                                <?php else: ?>
                                <a href="<?php echo e(route('new.adventure'.$adventure->stage,$adventure->id)); ?>" class="edit">ویرایش تور</a>

                                <?php endif; ?>
                                <button class="demo">پیش نمایش</button>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </div>

                </div>
            </div>
        </div>
    </div>
</div>
   <?php $__env->stopSection(); ?>

<?php echo $__env->make('main.site', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\laravelProject\mijoori\resources\views/home/my_adventures.blade.php ENDPATH**/ ?>