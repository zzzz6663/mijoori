   <?php $__env->startSection('content'); ?>
   <?php echo e(Breadcrumbs::render('user.index')); ?>


   <div class="col-lg-12">
    <div class="portlet box border shadow">
        <div class="portlet-heading">
            <div class="portlet-title">
                <h3 class="title">
                    <i class="icon-frane"></i>
                    جدول همکاران
                </h3>
            </div><!-- /.portlet-title -->
            <div class="buttons-box">
                <a href="<?php echo e(route('agent.create')); ?>" class="btn btn-success curve">همکار جدید</a>
            </div><!-- /.buttons-box -->
        </div><!-- /.portlet-heading -->
        <div class="portlet-body">
                

            <div class="table-responsive">
                <table class="table">
                    <thead>
                        <tr>


                            <th><i class="icon-energy"></i></th>
                            <th>نام</th>
                            <th>همراه </th>
                            <th>رمز </th>
                            <th>سطح</th>
                            <th>ایمیل</th>
                            <th>بیشتر</th>

                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <tr>
                            <td><?php echo e($loop->iteration + (($users->currentPage()-1) *($users->perPage()))); ?></td>
                            <td>
                                <?php echo e($user->name); ?>

                                <?php echo e($user->family); ?>

                            </td>
                            <td><?php echo e($user->mobile); ?></td>
                            <td><?php echo e($user->password); ?></td>
                            <td><?php echo e(__('arr.'.$user->level)); ?></td>
                            <td><?php echo e($user->email); ?></td>

                            <td>
                                <?php if($user->avatar()): ?>
                                <a  class="btn btn-secondary curve" href="<?php echo e($user->avatar()); ?>" data-lightbox="image-1" data-title="My caption">مشاهده   </a>
                                <?php endif; ?>
                                <?php if(auth()->check() && auth()->user()->hasRole('admin|manager')): ?>
                            <a class="btn btn-primary curve" href="<?php echo e(route('agent.edit',$user->id)); ?>">ویرایش</a>
                            <?php endif; ?>
                            <?php if(auth()->check() && auth()->user()->hasRole('admin')): ?>
                                <form action="<?php echo e(route('agent.destroy' ,$user->id)); ?>" method="POST" style="display:inline" >
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('delete'); ?>
                                <input type="submit"   onclick="return confirm('مایل به حذف هستید؟')" value="حذف" class="btn btn-danger curve">
                                </form>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                    </tbody>
                </table>
            </div><!-- /.table-responsive -->
        </div><!-- /.portlet-body -->
    </div><!-- /.portlet -->
</div>
   <?php $__env->stopSection(); ?>

<?php echo $__env->make('main.manager', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\laravelProject\mijoori\resources\views/admin/agent/all.blade.php ENDPATH**/ ?>