   <?php $__env->startSection('content'); ?>
   <?php echo e(Breadcrumbs::render('user.show',$user)); ?>


   <div class="col-lg-6">
    <div class="portlet box border shadow">
        <div class="portlet-heading">
            <div class="portlet-title">
                <h3 class="title">
                    <i class="icon-frane"></i>
                    پروفایل کاربر
                    <?php echo e($user->name); ?>

                    <?php echo e($user->family); ?>

                </h3>
            </div><!-- /.portlet-title -->
            <div class="buttons-box">

            </div><!-- /.buttons-box -->
        </div><!-- /.portlet-heading -->
        <div class="portlet-body">
            <div class="portlet-title">

                <div   class="text-center">
                    <img src="<?php echo e($user->avatar()); ?>" alt="">

                </div>
                <div   class="text-center">
                  <h1>
                    <?php echo e($user->name); ?>

                    <?php echo e($user->family); ?>

                  </h1>
                </div>
                <div class="">
                    <div class="row">
                        <div class="col-lg-3">
                            همراه
                        </div>
                        <div class="col-lg-9">
                            <span class="text-center">
                                <?php echo e($user->mobile); ?>

                            </span>

                        </div>
                    </div>
                    <div class="row">
                        <div class="col-lg-3">
                            ایمیل
                        </div>
                        <div class="col-lg-9">
                            <span class="text-center">
                                <?php echo e($user->email); ?>

                            </span>

                        </div>
                    </div>
                    <div class="row">
                        <div class="col-lg-3">
                            مکان
                        </div>
                        <div class="col-lg-9">
                            <span class="text-center">
                                <?php echo e($user->province?$user->province->name:''); ?>

                                <?php echo e($user->city?$user->city->name:''); ?>

                            </span>

                        </div>
                    </div>
                    <div class="row">
                        <div class="col-lg-3">
                            جنسیت
                        </div>
                        <div class="col-lg-9">
                            <span class="text-center">
                                <?php echo e($user->gender()); ?>

                            </span>

                        </div>
                    </div>
                    <div class="row">
                        <div class="col-lg-3">
                             کدملی
                        </div>
                        <div class="col-lg-9">
                            <span class="text-center">
                                <?php echo e($user->code); ?>

                            </span>

                        </div>
                    </div>
                    <div class="row">
                        <div class="col-lg-3">
                             ادرس
                        </div>
                        <div class="col-lg-9">
                            <span class="text-center">
                                <?php echo e($user->address); ?>

                            </span>

                        </div>
                    </div>
                    <div class="row">
                        <div class="col-lg-3">
                             تاریخ تولد
                        </div>
                        <div class="col-lg-9">
                            <span class="text-center">
                                <?php echo e($user->fdate($user->b_date)); ?>

                            </span>

                        </div>
                    </div>
                    <div class="row">
                        <div class="col-lg-3">
                             تاریخ ثبت
                        </div>
                        <div class="col-lg-9">
                            <span class="text-center">
                                <?php echo e($user->fdate($user->created_at)); ?>

                            </span>

                        </div>
                    </div>
                    <?php if($user->travels()->count()>0): ?>
                    <div class="row">
                        <div class="col-lg-3">
                               سفر ها
                        </div>
                        <div class="col-lg-9">
                            <span class="text-center">
                                <a class="btn btn-warning curve" href="<?php echo e(route('travel.index',['mobile'=>$user->mobile])); ?>">سفر ها</a>
                            </span>
                        </div>
                    </div>
                    <?php endif; ?>
                    <?php if($user->adventures()->count()>0): ?>
                    <br>
                    <div class="row">
                        <div class="col-lg-3">
                                 ماجراجویی ها
                        </div>
                        <div class="col-lg-9">
                            <span class="text-center">
                                <a class="btn btn-secondary  curve" href="<?php echo e(route('adventure.index',['mobile'=>$user->mobile])); ?>">ماجراجویی ها</a>
                            </span>
                        </div>
                    </div>
                    <?php endif; ?>
                    <br>

                    <div class="row">
                        <div class="col-lg-3">
                             وضعیت  راهنما
                        </div>
                        <div class="col-lg-9">
                            <?php if($user->guid ): ?>
                            <?php echo e($user->active ? "  فعال":' غیر فعال'); ?>


                            <a class="btn btn-<?php echo e($user->active?'danger':'success'); ?> curve" href="<?php echo e(route('user.active.guid',$user->id)); ?>">
                                    <?php echo e($user->active ? "غیر فعال":'  فعال'); ?>

                            </a>
                            <?php endif; ?>

                        </div>
                    </div>
<br>
<?php if($user->guid ): ?>
                    <div class="row">
                        <div class="col-lg-3">
                             عکس ها
                        </div>
                        <div class="col-lg-9">
                            <a class="btn btn-default curve" target="_blank" href="<?php echo e($user->melli_back()); ?>">
                                 پشت کارت
                            </a>
                            <a class="btn btn-warning curve" target="_blank" href="<?php echo e($user->melli_front()); ?>">
                                 جلوی  کارت
                            </a>
                            <a class="btn btn-info curve" target="_blank" href="<?php echo e($user->tourism()); ?>">
                                گردشگری
                            </a>

                        </div>
                    </div>
                    <?php endif; ?>
                </div>
            </div>


        </div><!-- /.portlet-body -->
    </div><!-- /.portlet -->
</div>


<div class="breadcrumb-box border shadow">
    <ul class="breadcrumb">
        <a href="<?php echo e(route('user.index')); ?>" class="btn btn-danger">برگشت</a>
            </ul>

    </div><!-- /.breadcrumb-left -->
</div>
   <?php $__env->stopSection(); ?>

<?php echo $__env->make('main.manager', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\laravelProject\mijoori\resources\views/admin/users/show.blade.php ENDPATH**/ ?>