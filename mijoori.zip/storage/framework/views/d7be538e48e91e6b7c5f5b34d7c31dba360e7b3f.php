   <?php $__env->startSection('content'); ?>
   <?php echo e(Breadcrumbs::render('language.index')); ?>

    <div class="col-lg-12">
        <div class="portlet box border shadow">
            <div class="portlet-heading">
                <div class="portlet-title">
                    <h3 class="title">
                        <i class="icon-frane"></i>
                        جدول زبان  ها
                    </h3>
                </div><!-- /.portlet-title -->
                <div class="buttons-box">
                    <a href="<?php echo e(route('language.create')); ?>" class="btn btn-success curve">زبان جدید</a>
                </div>
            </div><!-- /.portlet-heading -->
            <div class="portlet-body">
                <form action="<?php echo e(route('language.index')); ?>" method="get">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('get'); ?>
                    <div class="row">
                        

                        
                        
                    </div>

                </form>
                <div class="table-responsive">
                    <table class="table">
                        <thead>
                            <tr>
                                <th><i class="icon-energy"></i></th>
                                <th>نام</th>
                                <th>   تعداد اشخاص </th>
                                <th>  اقدام </th>
                            </tr>
                        </thead>
                        <tbody>
                           <?php $__currentLoopData = $languages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $language): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                           

                           <tr>
                            <td><?php echo e($loop->iteration); ?></td>
                            <td><?php echo e($language->name); ?></td>

                            <td><?php echo e($language->users()->count()); ?>

                            مشتری
                            </td>
                            <td>
                                <a class="btn btn-primary curve" href="<?php echo e(route('language.edit',$language->id)); ?>">
                                    تغییر نام
                                </a>

                            </td>
                        </tr>

                           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    <div class="pagi">
                        <?php echo e($languages->appends(Request::all())->links('admin.section.pagination')); ?>

                    </div>
                </div><!-- /.table-responsive -->
            </div><!-- /.portlet-body -->
        </div><!-- /.portlet -->
    </div>


   <?php $__env->stopSection(); ?>

<?php echo $__env->make('main.manager', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\laravelProject\mijoori\resources\views/admin/language/all.blade.php ENDPATH**/ ?>