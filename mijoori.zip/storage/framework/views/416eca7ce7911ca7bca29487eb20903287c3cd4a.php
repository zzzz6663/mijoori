   <?php $__env->startSection('content'); ?>
    <?php echo $__env->make('main.breadcrumbs', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="col-lg-12">
        <div class="portlet box border shadow">
            <div class="portlet-heading">
                <div class="portlet-title">
                    <h3 class="title">
                        <i class="icon-frane"></i>
                        جدول کاربران
                    </h3>
                </div><!-- /.portlet-title -->
                <div class="buttons-box">

                </div><!-- /.buttons-box -->
            </div><!-- /.portlet-heading -->
            <div class="portlet-body">
                <form action="">
                    <div class="row">
                        <div class="col-lg-3">
                            <div class="form-group row">
                                <label class="col-sm-3">نام</label>
                                <div class="col-sm-9">
                                    <input type="text" class="form-control" placeholder="نام">
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-3">
                            <div class="form-group row">
                                <label class="col-sm-3">نام</label>
                                <div class="col-sm-9">
                                    <input type="text" class="form-control" placeholder="نام">
                                </div>
                            </div>
                        </div>
                    </div>

                </form>
                <div class="table-responsive">
                    <table class="table">
                        <thead>
                            <tr>
                                <th><i class="icon-energy"></i></th>
                                <th>نام</th>
                                <th>   تعداد شهرستان </th>
                                <th>   تعداد اشخاص </th>
                                <th>  اقدام </th>
                            </tr>
                        </thead>
                        <tbody>
                           <?php $__currentLoopData = App\Models\Province::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $province): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                           

                           <tr>
                            <td><?php echo e($loop->iteration); ?></td>
                            <td><?php echo e($province->name); ?></td>
                            <td><?php echo e($province->cities()->count()); ?>

                            شهر
                            </td>
                            <td><?php echo e($province->users()->count()); ?>

                            مشتری
                            </td>
                            <td>


                                <a class="btn btn-primary curve" href="<?php echo e(route('province.edit',$province->id)); ?>">
                                    عکس
                                </a>
                                <?php if($province->image()): ?>
                                <a  class="btn btn-secondary curve" href="<?php echo e($province->image()); ?>" data-lightbox="image-1" data-title="My caption">مشاهده   </a>

                                <?php endif; ?>
                                <?php if($province->users()->count()): ?>

                                <a class="btn btn-success curve" href="<?php echo e(route('province.show',$province->id)); ?>">
                                    لیست اشخاص
                                </a>
                                <?php endif; ?>

                            </td>
                        </tr>

                           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div><!-- /.table-responsive -->
            </div><!-- /.portlet-body -->
        </div><!-- /.portlet -->
    </div>

    
   <?php $__env->stopSection(); ?>

<?php echo $__env->make('main.manager', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\laravelProject\mijoori\resources\views/admin/provinces/all.blade.php ENDPATH**/ ?>