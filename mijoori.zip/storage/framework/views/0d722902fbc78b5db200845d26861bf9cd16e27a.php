  <!-- BEGIN SIDEBAR -->
  <div id="sidebar">
    <div class="sidebar-top">
        
        <div class="user-box">
            <a href="#">
                <img src="assets/images/user/128.png" alt="عکس پروفایل" class="img-circle img-responsive">
            </a>
            <div class="user-details">
                <h4>
                    <?php echo e(auth()->user()->name); ?>

                    <?php echo e(auth()->user()->family); ?></h4>
                <p class="role">  <?php echo e(__('arr.'.auth()->user()->level)); ?></p>
                <div class="dropdown user-login">
                    
                    <ul class="dropdown-menu dropdown-status">
                        <li>
                            <a href="#" class="busy">
                                <i class="fa fa-circle text-success"></i>
                                <span>دردسترس</span>
                            </a>
                        </li>
                        <li>
                            <a href="#" class="busy">
                                <i class="fa fa-circle text-danger"></i>
                                <span>مشغول</span>
                            </a>
                        </li>
                        <li>
                            <a href="#">
                                <i class="fa fa-circle text-gray"></i>
                                <span>مخفی</span>
                            </a>
                        </li>
                        <li>
                            <a href="#">
                                <i class="fa fa-circle text-warning"></i>
                                <span>سایر</span>
                            </a>
                        </li>
                    </ul>
                </div><!-- /dropdown -->
            </div><!-- /.user-details -->
        </div><!-- /.user-box -->
    </div><!-- /.sidebar-top -->
    <div class="side-menu-container">
        <ul class="metismenu" id="side-menu">
            <li>
                <a href="<?php echo e(route('user.index')); ?>" class="<?php echo e(Request::url()== route( 'user.index')?'current':''); ?>">
                    <i class="fa fa-users" aria-hidden="true"></i>
                    <span>کاربران</span>
                </a>

            </li>
            <li>
                <a href="<?php echo e(route('province.index')); ?>" class="<?php echo e(Request::url()== route( 'province.index')?'current':''); ?>">
                    <i class="fa fa-map-marker" aria-hidden="true"></i>
                    <span>استان ها</span>
                </a>

            </li>
            <li>
                <a href="<?php echo e(route('logout')); ?>" class="<?php echo e(Request::url()== route( 'logout')?'current':''); ?>">
                    <span aria-hidden="true" class="icon-logout"></span>
                    <span>  خروج</span>
                </a>

            </li>

        </ul><!-- /#side-menu -->
    </div><!-- /.side-menu-container -->
</div><!-- /#sidebar -->
<!-- END SIDEBAR -->
<?php /**PATH G:\laravelProject\mijoori\resources\views/admin/section/sidebar.blade.php ENDPATH**/ ?>