<?php $__env->startSection('content'); ?>
<?php echo e(Breadcrumbs::render('language.edit',$language)); ?>


 <div class="col-lg-6">
     <div class="portlet box border shadow">
         <div class="portlet-heading">
             <div class="portlet-title">
                 <h3 class="title">
                     <i class="icon-frane"></i>
                     به روز رسانی  زبان
                     <?php echo e($language->name); ?>


                 </h3>
             </div><!-- /.portlet-title -->
             <div class="buttons-box">

             </div><!-- /.buttons-box -->
         </div><!-- /.portlet-heading -->
         <div class="portlet-body">
             <?php echo $__env->make('main.error', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
             <form action="<?php echo e(route('language.update',$language->id )); ?>" method="post"  >
                 <?php echo csrf_field(); ?>
                 <?php echo method_field('PATCH'); ?>
                 <div class="row">
                     <div class="col-lg-12">


                         <div class="form-group relative">
                             <label>  نام زبان</label>

                             <input type="text"    name="name" value="<?php echo e(old('name',$language->name)); ?>" class="form-control">

                         </div>
                         <div class="form-group relative">
                             <button type="submit" class="btn btn-info curve">
                                 ویرایش
                             <div class="paper-ripple"><div class="paper-ripple__background"></div><div class="paper-ripple__waves"></div></div></button>
                         </div>
                     </div>

                 </div>

             </form>

         </div><!-- /.portlet-body -->
     </div><!-- /.portlet -->
 </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('main.manager', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\laravelProject\mijoori\resources\views/admin/language/edit.blade.php ENDPATH**/ ?>