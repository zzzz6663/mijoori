<option  >استان را انتخاب کنید </option>
<?php $__currentLoopData = $province->cities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $citei): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <option value="<?php echo e($citei->id); ?>"><?php echo e($citei->name); ?></option>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH G:\laravelProject\mijoori\resources\views/home/parts/get_city.blade.php ENDPATH**/ ?>