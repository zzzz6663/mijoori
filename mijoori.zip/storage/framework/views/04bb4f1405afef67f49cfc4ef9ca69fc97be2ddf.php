<?php if (! ($breadcrumbs->isEmpty())): ?>

<div class="col-md-12">
    <div class="breadcrumb-box border shadow">
        <ul class="breadcrumb">

            <?php $__currentLoopData = $breadcrumbs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $breadcrumb): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <?php if($breadcrumb->url && !$loop->last): ?>
                <li class="breadcrumb-item"><a href="<?php echo e($breadcrumb->url); ?>"><?php echo e($breadcrumb->title); ?></a></li>
            <?php else: ?>
                <li class="breadcrumb-item active" aria-current="page"><?php echo e($breadcrumb->title); ?></li>
            <?php endif; ?>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
        <div class="breadcrumb-left">
           <?php echo e(\Morilog\Jalali\Jalalian::now()); ?>

            <i class="icon-calendar"></i>
        </div><!-- /.breadcrumb-left -->
    </div><!-- /.breadcrumb-box -->
</div>



<?php endif; ?>
<?php /**PATH G:\laravelProject\mijoori\resources\views/vendor/breadcrumbs/bootstrap5.blade.php ENDPATH**/ ?>