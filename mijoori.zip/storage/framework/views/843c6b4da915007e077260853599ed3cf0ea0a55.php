
<div class="navbar navbar-fixed-top" id="main-navbar">
    <div class="header-right">
        <a href="dashboard.html" class="logo-con">
            <img src="assets/images/logo.png" class="img-responsive center-block" alt="لوگو قالب مدیران">
        </a>
    </div><!-- /.header-right -->
    <div class="header-left">
        <div class="top-bar">
            <ul class="nav navbar-nav navbar-right">
                <li>
                    <a href="#" class="btn" id="toggle-sidebar">
                        <span class="menu"></span>
                    <div class="paper-ripple"><div class="paper-ripple__background"></div><div class="paper-ripple__waves"></div></div></a>
                </li>
                <li>
                    <a href="#" class="btn open" id="toggle-sidebar-top">
                        <i class="icon-user-following"></i>
                    <div class="paper-ripple"><div class="paper-ripple__background"></div><div class="paper-ripple__waves"></div></div></a>
                </li>
                <li>
                    <a href="#" class="btn" id="toggle-dark-mode">
                        <i class="icon-bulb"></i>
                    <div class="paper-ripple"><div class="paper-ripple__background"></div><div class="paper-ripple__waves"></div></div></a>
                </li>
            </ul>
            <ul class="nav navbar-nav navbar-left">
                <li class="dropdown">
                    <a href="#" class="btn" id="toggle-fullscreen">
                        <i class="icon-size-fullscreen"></i>
                    <div class="paper-ripple"><div class="paper-ripple__background"></div><div class="paper-ripple__waves"></div></div></a>
                </li>
                <li class="dropdown dropdown-messages">
                    <a href="#" class="dropdown-toggle btn" data-bs-toggle="dropdown">
                        <i class="icon-envelope"></i>
                        <span class="badge badge-primary">
                            3
                        </span>
                    <div class="paper-ripple"><div class="paper-ripple__background"></div><div class="paper-ripple__waves"></div></div></a>
                    <ul class="dropdown-menu has-scrollbar mCustomScrollbar _mCS_1 mCS-autoHide mCS-dir-rtl mCS_no_scrollbar" style="height: 300px; overflow: visible;"><div id="mCSB_1" class="mCustomScrollBox mCS-minimal-dark mCSB_vertical mCSB_outside" style="max-height: 298px;" tabindex="0"><div id="mCSB_1_container" class="mCSB_container mCS_y_hidden mCS_no_scrollbar_y" style="position:relative; top:0; left:0;" dir="rtl">
                        <li class="dropdown-header clearfix">
                            <span class="float-start">
                                <a href="#" rel="tooltip" title="" data-placement="left" data-bs-original-title="خواندن همه">
                                    <i class="icon-eye"></i>
                                </a>
                            سه سفر اخر
                            </span>
                        </li>
                        <li class="dropdown-body">
                            <ul class="dropdown-menu-list">
                                <?php $__currentLoopData = App\Models\Travel::latest()->take(3)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $travel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                <li class="clearfix">
                                    <a href="#">
                                        <p class="clearfix">
                                            <strong class="float-start">
                                                <img src="<?php echo e($travel->user->avatar()); ?>" class="img-circle mCS_img_loaded" alt="">
                                                  <?php echo e($travel->user->name); ?>

                                                  <?php echo e($travel->user->family); ?>

                                            </strong>
                                            <small class="float-end text-muted">
                                                <i class="icon-clock"></i>
                                                <?php echo e(Morilog\Jalali\Jalalian::forge($travel->start)->format("Y-m-d")); ?>

                                            </small>
                                        </p>
                                      <p>
                                        <?php echo e($travel->city->name); ?>

                                      </p>
                                    </a>
                                </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </ul>
                        </li>
                        <li class="dropdown-footer clearfix">
                            <a href="<?php echo e(route('travel.index')); ?>">
                                <i class="icon-list fa-flip-horizontal"></i>
                                مشاهده سفر ها
                            </a>
                        </li>
                    </div></div><div id="mCSB_1_scrollbar_vertical" class="mCSB_scrollTools mCSB_1_scrollbar mCS-minimal-dark mCSB_scrollTools_vertical" style="display: none;"><div class="mCSB_draggerContainer"><div id="mCSB_1_dragger_vertical" class="mCSB_dragger" style="position: absolute; min-height: 50px; top: 0px;"><div class="mCSB_dragger_bar" style="line-height: 50px;"></div></div><div class="mCSB_draggerRail"></div></div></div></ul>
                </li>
                

            </ul><!-- /.navbar-left -->
        </div><!-- /.top-bar -->
    </div><!-- /.header-left -->
</div>
<?php /**PATH G:\laravelProject\mijoori\resources\views/admin/section/navbar.blade.php ENDPATH**/ ?>