@extends('main.site')
@section('content')
<div id="top-banner" class="rows">
    <img src="/home/images/custom.png" alt="">
</div>


@endsection
