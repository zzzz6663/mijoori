@extends('main.site')
@section('content')
<div id="top-banner" class="rows">
    <img src="{{$target_city->banner()}}" alt="">
</div>


@endsection
