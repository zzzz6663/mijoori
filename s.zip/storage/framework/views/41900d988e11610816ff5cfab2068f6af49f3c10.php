<?php $__env->startSection('content'); ?>
<div id="top-banner" class="rows">
    <img src="/home/images/custom.png" alt="">
</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('main.site', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\laravelProject\mijoori\resources\views/home/custom_travel.blade.php ENDPATH**/ ?>