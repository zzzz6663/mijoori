   <?php $__env->startSection('content'); ?>
   <?php echo e(Breadcrumbs::render('city.index')); ?>

    <div class="col-lg-12">
        <div class="portlet box border shadow">
            <div class="portlet-heading">
                <div class="portlet-title">
                    <h3 class="title">
                        <i class="icon-frane"></i>
                        جدول شهر ها
                    </h3>
                </div><!-- /.portlet-title -->
                <div class="buttons-box">

                </div><!-- /.buttons-box -->
            </div><!-- /.portlet-heading -->
            <div class="portlet-body">
                <form action="<?php echo e(route('city.index')); ?>" method="get">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('get'); ?>
                    <div class="row">
                        <div class="col-lg-3">
                            <div class="form-group row">
                                <label class="col-sm-3">جست و جو</label>
                                <div class="col-sm-9">
                                    <input type="text" class="form-control" name="search" value="<?php echo e(request('search')); ?>" placeholder=" نام شهر یا استان   ">
                                </div>
                            </div>
                        </div>

                        
                        <div class="col-lg-3">
                            <div class="form-group row">
                                <button class="btn btn-danger curve" ">ثبت</button>
                            </div>
                        </div>
                    </div>

                </form>
                <div class="table-responsive">
                    <table class="table">
                        <thead>
                            <tr>
                                <th><i class="icon-energy"></i></th>
                                <th>نام</th>
                                <th>     نام استان </th>
                                <th>   تعداد اشخاص </th>
                                <th>  اقدام </th>
                            </tr>
                        </thead>
                        <tbody>
                           <?php $__currentLoopData = $cities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                           

                           <tr>
                            <td><?php echo e($loop->iteration); ?></td>
                            <td><?php echo e($city->name); ?></td>
                            <td><?php echo e($city->province->name); ?>


                            </td>
                            <td><?php echo e($city->users()->count()); ?>

                            مشتری
                            </td>
                            <td>

                                <?php if(auth()->check() && auth()->user()->hasRole('admin|manager')): ?>
                                <a class="btn btn-primary curve" href="<?php echo e(route('city.edit',$city->id)); ?>">
                                    تغییر عکس
                                </a>
                                 <?php endif; ?>
                                <?php if($city->image()): ?>
                                <a  class="btn btn-secondary curve" href="<?php echo e($city->image()); ?>" data-lightbox="image-<?php echo e($city->image); ?>" data-title="My caption">مشاهده عکس   </a>
                                <?php endif; ?>
                                <?php if($city->banner()): ?>
                                <a  class="btn btn-secondary curve" href="<?php echo e($city->banner()); ?>" data-lightbox="image-<?php echo e($city->banner); ?>" data-title="My caption">مشاهده بنر   </a>
                                <?php endif; ?>

                                <?php if($city->users()->count()): ?>
                                <a class="btn btn-success curve" href="<?php echo e(route('city.show',$city->id)); ?>">
                                    لیست اشخاص
                                </a>
                                <?php endif; ?>

                            </td>
                        </tr>

                           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    <div class="pagi">
                        <?php echo e($cities->appends(Request::all())->links('admin.section.pagination')); ?>

                    </div>
                </div><!-- /.table-responsive -->
            </div><!-- /.portlet-body -->
        </div><!-- /.portlet -->
    </div>


   <?php $__env->stopSection(); ?>

<?php echo $__env->make('main.manager', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\laravelProject\mijoori\resources\views/admin/cities/all.blade.php ENDPATH**/ ?>