   <?php $__env->startSection('content'); ?>
   <?php echo e(Breadcrumbs::render('adventure.index')); ?>


   <div class="col-lg-12">
    <div class="portlet box border shadow">
        <div class="portlet-heading">
            <div class="portlet-title">
                <h3 class="title">
                    <i class="icon-frane"></i>
                    جدول ماجراجویی
                </h3>
            </div><!-- /.portlet-title -->
            <div class="buttons-box">
            </div><!-- /.buttons-box -->
        </div><!-- /.portlet-heading -->
        <div class="portlet-body">
                <div class="row">
                    <form action="<?php echo e(route('adventure.index')); ?>" method="get">

                    <div class="col-lg-3">
                        <div class="form-group row">
                            <label class="col-sm-3">جست و جو</label>
                            <div class="col-sm-9">
                                <input type="text" class="form-control" name="search" value="<?php echo e(request('search')); ?>" placeholder="  نام و موبایل و ....  ">
                            </div>
                        </div>
                    </div>
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('get'); ?>
                    <div class="col-lg-3">
                        <div class="form-group row">
                            <button class="btn btn-danger curve" ">ثبت</button>
                        </div>
                    </div>
                </form>
                </div>

            <div class="table-responsive">
                <table class="table">
                    <thead>
                        <tr>


                            <th><i class="icon-energy"></i></th>
                            <th>نام</th>
                            <th>شهر </th>
                            <th>تعداد </th>
                            <th>دسته بندی </th>
                            <th>وضعیت </th>
                            <th>تایید</th>
                            <th>اقداام</th>

                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $adventures; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $adventure): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($loop->iteration + (($adventures->currentPage()-1) *($adventures->perPage()))); ?></td>
                            <td>
                               <a target="_blank" href="<?php echo e(route('user.show',$adventure->user->id)); ?>">
                                <?php echo e($adventure->user->name); ?>

                                <?php echo e($adventure->user->family); ?>

                               </a>
                            </td>
                            <td>
                                <?php echo e($adventure->city->name); ?>

                                <?php echo e($adventure->province->name); ?>

                            </td>
                            <td>
                                <?php echo e($adventure->count); ?>

                            </td>
                            <td>
                                <?php echo e(__('arr.'.$adventure->cat)); ?>

                            </td>
                            <td>
                                <?php if($adventure->stage==5): ?>
تکمیل شده
                                <?php else: ?>
                                در مرحله
                            <?php echo e($adventure->stage); ?>

                                <?php endif; ?>

                            </td>

                            <td>
                                <span class="text text-<?php echo e($adventure->confirm?"success":'danger'); ?>">
                                 (<?php echo e($adventure->confirm?"تایید شده":'تایید نشده'); ?>)
                                </span>
                             </td>

                            <td>
                                (<?php echo e($adventure->confirm?"تایید شده":'تایید نشده'); ?>)
                            <?php if(auth()->check() && auth()->user()->hasRole('admin')): ?>
                            <?php if(!$adventure->confirm): ?>
                            <a class="btn btn-<?php echo e($adventure->confirm?"danger":'primary'); ?> curve" href="<?php echo e(route('adventure.confirm',$adventure->id)); ?>"><?php echo e($adventure->confirm?"  رد":'  تایید'); ?></a>
                            <?php endif; ?>
                                <?php endif; ?>
                            <a href="<?php echo e(route('adventure.show',$adventure->id)); ?>" class="btn btn-success curve">جزئیات</a>

                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                    </tbody>
                </table>
            </div><!-- /.table-responsive -->
        </div><!-- /.portlet-body -->
    </div><!-- /.portlet -->
</div>
   <?php $__env->stopSection(); ?>

<?php echo $__env->make('main.manager', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\laravelProject\mijoori\resources\views/admin/adventures/all.blade.php ENDPATH**/ ?>