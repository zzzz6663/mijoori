   <?php $__env->startSection('content'); ?>

   <div id="search-section" class="rows">
    <div class="container">
        <div class="row">
            <div class="col-lg-10 col-sm-12 center-block">
                <div>
                    <h1>
                        سـفر، مـاجراجـویی، تجربه گردی
                        <span>در میجــوری</span>
                    </h1>

                    <div id="search-2">
                        <form action="<?php echo e(route('guides')); ?>" autocomplete="off">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('get'); ?>
                            <span class="icon">
                                

                            </span>
                            <div class="autocomplete" style="width:100%;background: #fff; padding: 0 10px;
                            box-sizing: border-box;">
                                <input type="text" name="city" id="mycity" data-city='<?php echo e(json_encode($cities->pluck('name')->toArray())); ?>' placeholder="مقصد شما کجاست؟">

                            </div>
                            <button>جستجو</button>

                        </form>
                        <script>


                        </script>
                        <div class="caption">
                            <p>

                                پربازدیدترین مقصدها:
                                <?php
                                    $seens=App\Models\City::orderBy('count','desc')->take(5)->get();
                                ?>
                            <span>
                                <?php $__currentLoopData = $seens; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $seen): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php echo e($seen->name); ?> ,
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            ....

                            </span>
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div id="trip-guides" class="rows">
    <div class="fullcontainer">
        <div class="row">
            <div class="col-lg-12">
                <div>

                    <div class="title-more">
                        <h3>راهنماهای میجوری</h3>
                        <div class="more">
                            <a href="<?php echo e(route('guides')); ?>">همه ی راهنماها</a>
                        </div>
                    </div>

                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-12">
                <div>
                    <ul class="fave-guid-list owl-carousel owl-theme side-nav">
                        <?php $__currentLoopData = $guids; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $guid): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                             <li>
                                <div class="">
                                    <div>
                                        <div class="single-host-det">
                                            <div class="img">
                                                <a href="<?php echo e(route('profile',$guid->id)); ?>">
                                                    <img src="<?php echo e($guid->avatar()); ?>" alt="">
                                                </a>
                                                <button class="like">
                                                    <svg xmlns="http://www.w3.org/2000/svg" width="27.721" height="25.217" viewBox="0 0 27.721 25.217">
                                                        <path id="Path_30" data-name="Path 30" d="M308.094,370.632l-10.486,10.487-10.486-10.487c-3.964-3.636-3.507-9.605-.249-12.147,2.831-2.209,7.735-1.8,10.735,1.661,2.978-3.563,8.109-3.874,11.021-1.361C311.806,361.527,311.973,367.313,308.094,370.632Z" transform="translate(-283.789 -356.608)" fill="#fff" stroke="#000" stroke-width="1"></path>
                                                    </svg>
                                                </button>

                                                <div class="info">
                                                    <div class="top">
                                                        <h4><a href="<?php echo e(route('profile',$guid->id)); ?>">    <?php echo e($guid->name); ?> <?php echo e($guid->family); ?></a></h4>
                                                        <span class="city"><?php echo e($guid->province?$guid->province->name:''); ?></span>
                                                    </div>
                                                    <div class="top">
                                                        <span class="lig"  style=""><?php echo e($guid->about); ?>       </span>
                                                    </div>
                                                    <ul>
                                                        <li>
                                                            <span class="right">
                                                                <span class="rate">
                                                                    <?php echo $__env->make('home.parts.rate',['rate'=>$guid ->rates()], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                                                </span>
                                                            </span>
                                                            <span class="left">
                                                                <span class="price"> 50/000 تومان</span>
                                                            </span>
                                                        </li>
                                                        <li>
                                                            <span class="right">
                                                                <span class="day">
                                                                    <?php echo e($guid ->comments_count()->count()); ?>

                                                                     دیدگاه
                                                                </span>
                                                            </span>
                                                            <span class="left">
                                                                <span class="time">
                                                                    روزانه
                                                                </span>
                                                            </span>
                                                        </li>
                                                    </ul>
                                                </div>
                                            </div>
                                            
                                        </div>
                                    </div>
                                </div>
                             </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </ul>
                </div>
            </div>


        </div>
    </div>
</div>

<div id="fave-city" class="rows">
    <div class="fullcontainer">
        <div class="row">
            <div class="col-lg-12">
                <div>

                    <div class="title-more">
                        <h3>مقاصد گردشگری</h3>
                        <div class="more">
                            <a href="<?php echo e(route('all.cities')); ?>">همه ی شهرها</a>
                        </div>
                    </div>

                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-12">
                <div>
                    <ul class="fave-hosts-list owl-carousel owl-theme side-nav">
                        <?php $__currentLoopData = App\Models\City::take(10)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if(!file_exists(public_path('/media/city/small'.$city->image))): ?>
                        <?php continue; ?>
                        <?php endif; ?>
                        <li>
                            <div class="single-city">
                                <div class="img">
                                    <a href="<?php echo e(route('single.city',$city->id)); ?>">
                                        <img src="<?php echo e($city->image('small')); ?>" alt="">
                                    </a>
                                    <h4><a href="<?php echo e(route('single.city',$city->id)); ?>"><?php echo e($city->name); ?></a></h4>
                                </div>

                            </div>
                        </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>

<div id="how-to1" class="rows">
    <div class="fullcontainer">
        <div class="how-to-box">
            <div class="top">
                <h3>تجربه ی جدید</h3>
                <p>یک سفر بسازید و از راهنماهای میجوری پیشنهاد سفر دریافت کنید .</p>
            </div>

            <div class="row">
                <div class="col-lg-4 col-sm-12">
                    <div>

                        <div class="how-to-lev">
                            <span class="num">1</span>
                            <span class="title">سفر سفارشی خود را بسازید .</span>
                        </div>

                    </div>
                </div>
                <div class="col-lg-4 col-sm-12">
                    <div>

                        <div class="how-to-lev">
                            <span class="num">2</span>
                            <span class="title">از راههای میجوری پیشنهاد دریافت کنید .</span>
                        </div>

                    </div>
                </div>
                <div class="col-lg-4 col-sm-12">
                    <div>

                        <div class="how-to-lev">
                            <span class="num">3</span>
                            <span class="title">راهنمای مورد علاقه خود را انتخاب کنید .</span>
                        </div>

                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-lg-12">
                    <div class="link">
                        <a class="btn " href="<?php echo e(route('custom.travel')); ?>">سفر سفارشی بسازید</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php if($last_travels->count()>0): ?>

<div id="new-reserve" class="rows">
    <div class="fullcontainer">

        <div class="row">
            <div class="col-lg-12">
                <div>

                    <div class="title-more">
                        <h3>رزروهای اخیر</h3>

                    </div>

                </div>
            </div>
        </div>

        <div class="reserves">


            <div class="row">
<?php $__currentLoopData = $last_travels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ls): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <div class="col-lg-4 col-md-12">
                    <div>
                        <div class="single-erserv">
                            <div class="top">
                                <div class="img">
                                    <img src="<?php echo e($ls->host->city?$ls->host->city->image():''); ?>">
                                </div>
                                <div class="user">
                                   <a href="<?php echo e(route('profile',$ls->host->id)); ?>">
                                    <img src="<?php echo e($ls->host->avatar()); ?>" alt="">
                                   </a>
                                </div>
                                <div class="price">
                                    <div>

                                    <span>
                                        250/000
                                    </span>
                                    <span>تومان</span>
                                    </div>
                                </div>
                            </div>
                            <div class="info">
                                <h4>
                                    <?php echo e($ls->host->name); ?>

                                    <?php echo e($ls->host->family); ?>

                                </h4>
                                <span class="city"> <?php echo e($ls->host->city?$ls->host->city->name:''); ?></span>
                            </div>
                            <div class="bot">
                                <div class="right">
                                    <div class="img">
                                        <img src="<?php echo e($ls->user->avatar()); ?>" alt="">
                                    </div>
                                    <h5>

                                        <?php echo e($ls->user->name); ?>

                                        <?php echo e($ls->user->family); ?>

                                    </h5>
                                    <div class="star">
                                        <?php echo $__env->make('home.parts.rate',['rate'=>$ls->host->rates()], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                    </div>
                                </div>
                                <div class="left">
                                    <p>
                                        <?php
                                            $chat=$ls->chats()->oldest()->first();
                                        ?>
                                        <?php echo e($chat->chat); ?>

                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>
        </div>
    </div>
</div>
<?php endif; ?>




   <?php $__env->stopSection(); ?>

<?php echo $__env->make('main.site', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\laravelProject\mijoori\resources\views/home/index.blade.php ENDPATH**/ ?>